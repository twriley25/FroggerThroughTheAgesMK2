controls
---------------
movement
	w/up-arrow: move frogger forward 1 square
	d/right-arrow: move frogger right 1 square
	a/left-arrow: move frogger left 1 square
	s/down-arrow: move frogger back 1 square

menu navagation
	Escape: quit the game
	n: new game
	p: go to the title screen
	c: go to the credits
	u: go to the version notes
	1: go to the old version of Frogger

"secret controls"
	0: skip one scene forward